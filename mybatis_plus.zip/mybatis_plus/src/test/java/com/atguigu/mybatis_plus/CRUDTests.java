package com.atguigu.mybatis_plus;

import com.atguigu.mybatis_plus.entity.Product;
import com.atguigu.mybatis_plus.entity.User;
import com.atguigu.mybatis_plus.mapper.ProductMapper;
import com.atguigu.mybatis_plus.mapper.UserMapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author helen
 * @since 2020/3/31
 */
@SpringBootTest
public class CRUDTests {

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private ProductMapper productMapper;

    @Test
    public void testInsert(){

        User user = new User();
        user.setName("Helen");
        user.setEmail("55317332@qq.com");
        user.setAge(18);
//        user.setCreateTime(new Date());
//        user.setUpdateTime(new Date());

        //返回值：影响的行数
        int result = userMapper.insert(user);
        System.out.println("影响的行数：" + result);
        System.out.println("user id：" + user.getId());
    }

    @Test
    public void testUpdateById(){

        User user = new User();
        user.setId(1244892079889334273L);
        user.setAge(28);
        user.setName("Annie");
//        user.setUpdateTime(new Date());

        int result = userMapper.updateById(user);
        System.out.println("影响的行数：" + result);
    }


    @Test
    public void testConcurrentUpdate() {

        //1、小李获取数据
        Product p1 = productMapper.selectById(1L);
        System.out.println("小李取出的价格：" + p1.getPrice());

        //2、小王获取数据
        Product p2 = productMapper.selectById(1L);
        System.out.println("小王取出的价格：" + p2.getPrice());

        //3、小李加了50，存入数据库
        p1.setPrice(p1.getPrice() + 50);
        productMapper.updateById(p1);

        //4、小王减了30员，存入数据库
        p2.setPrice(p2.getPrice() - 30);
        int result = productMapper.updateById(p2);
        if(result == 0){
            System.out.println("小王更新失败");
            //发起重试
            p2 = productMapper.selectById(1L);
            p2.setPrice(p2.getPrice() - 30);
            productMapper.updateById(p2);
        }

        //最后的结果
        //用户看到的商品价格
        Product p3 = productMapper.selectById(1L);
        System.out.println("最后的结果：" + p3.getPrice());

    }


    @Test
    public void testSelectBatchIds(){
        List<User> users = userMapper.selectBatchIds(Arrays.asList(1, 2, 3));
        users.forEach(System.out::println);
    }

    @Test
    public void testSelectByMap(){

        HashMap<String, Object> map = new HashMap<>();
        map.put("name", "Helen");
        map.put("age", 18);

        List<User> users = userMapper.selectByMap(map);
        users.forEach(System.out::println);
    }

    @Test
    public void testSelectPage(){

        Page<User> page = new Page<>(1, 5);
        Page<User> pageParam = userMapper.selectPage(page, null);

        List<User> records = pageParam.getRecords();
        records.forEach(System.out::println);
        System.out.println(pageParam.getPages());//总页数
        System.out.println(pageParam.getTotal());//总记录数
        System.out.println(pageParam.getCurrent());//当前页码
        System.out.println(pageParam.getSize());//每页记录数
        System.out.println(pageParam.hasNext());//是否有下一页
        System.out.println(pageParam.hasPrevious());//是否有上一页
    }


    @Test
    public void testSelectMapsPage(){


        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("id", "name");

        Page<Map<String, Object>> page = new Page<>(1, 5);
        Page<Map<String, Object>> pageParam = userMapper.selectMapsPage(page, queryWrapper);

        List<Map<String, Object>> records = pageParam.getRecords();
        records.forEach(System.out::println);
        System.out.println(pageParam.getPages());//总页数
        System.out.println(pageParam.getTotal());//总记录数
        System.out.println(pageParam.getCurrent());//当前页码
        System.out.println(pageParam.getSize());//每页记录数
        System.out.println(pageParam.hasNext());//是否有下一页
        System.out.println(pageParam.hasPrevious());//是否有上一页
    }


    @Test
    public void testDeleteById(){
        int result = userMapper.deleteById(5L);
        System.out.println("删除了" + result + "行");
    }

    @Test
    public void testDeleteBatchIds(){
        int result = userMapper.deleteBatchIds(Arrays.asList(10, 11,12));
        System.out.println("删除了" + result + "行");
    }

    @Test
    public void testDeleteByMap(){

        HashMap<String, Object> map = new HashMap<>();
        map.put("name", "Helen");
        map.put("age", 18);

        int result = userMapper.deleteByMap(map);
        System.out.println("删除了" + result + "行");
    }

    @Test
    public void testLogicDeleteById(){
        int result = userMapper.deleteById(1L);
        System.out.println("删除了" + result + "行");
    }

    @Test
    void testLogicSelectList() {

        List<User> users = userMapper.selectList(null);
        users.forEach(System.out::println);
    }
}
